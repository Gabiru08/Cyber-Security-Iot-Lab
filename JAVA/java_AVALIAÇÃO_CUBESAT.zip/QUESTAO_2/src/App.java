public class App {
    public static void main(String[] args) throws Exception {
        PessoacomDoc pessoa1 = new PessoacomDoc("Evandro", 30, 1.75, "123456", "789012345");
        System.out.println("Nome: " + pessoa1.getNome());
        System.out.println("Idade: " + pessoa1.getIdade());
        System.out.println("Altura: " + pessoa1.getAltura());
        System.out.println("RG: " + pessoa1.getrg());
        System.out.println("CPF: " + pessoa1.getcpf());
        System.out.println("Ano de Nascimento: " + pessoa1.calcularAnoNascimento());
    }
}
// classe da pessoa
class Pessoa {
    private String nome;
    private int idade;
    private double altura;

    public Pessoa(String nome, int idade, double altura) {
        this.nome = nome;
        this.idade = idade;
        this.altura = altura;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;

    }

    public double getAltura() {
        return altura;

    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    public int calcularAnoNascimento() {
        int anoAtual = java.time.Year.now().getValue();
        return anoAtual - idade;
    }

}

// classe herdeira
class PessoacomDoc extends Pessoa {
    private String rg;
    private String cpf;

    public PessoacomDoc(String nome, int idade, double altura, String rg, String cpf) {
        super(nome, idade, altura);
        this.rg = rg;
        this.cpf = cpf;
    }

    public String getrg() {
        return rg;
    }

    public void setrg(String rg) {
        this.rg = rg;
    }

    public String getcpf() {
        return cpf;
    }

    public void setcpf(String cpf) {
        this.cpf = cpf;
    }

}