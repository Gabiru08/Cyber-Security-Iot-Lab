import java.util.Scanner;
public class App {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        // Solicita ao usuário para inserir o segundo valor
        System.out.print("Digite o segundo valor: ");
        int segundoValor = scan.nextInt();

        // Chama a função soma com o primeiro valor e o valor inserido pelo usuário
        int resultado = soma(10, segundoValor);

        // Imprime os valores e a soma
        System.out.println("Valor da primeira idade: 10");
        System.out.println("Valor da segunda idade: " + segundoValor);
        System.out.println("Soma das idades: " + resultado);
        scan.close();
    }

    public static int soma(int valorPadrao, int valorUsuario) {
        int resultado = valorPadrao + valorUsuario;
        return resultado;
    }
}