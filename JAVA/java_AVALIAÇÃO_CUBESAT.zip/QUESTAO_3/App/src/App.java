public class App {

    public static void main(String[] args)  {
        
        CalculadoraSalario calculadoraGrupo1 = new Grupo_1();
        CalculadoraSalario calculadoraGrupo2 = new Grupo_2();
        
        int expediente = 20;
        
        double salarioGrupo1 = calculadoraGrupo1.calcSalario(expediente);
        double salarioGrupo2 = calculadoraGrupo2.calcSalario(expediente);
        System.out.println("Salario Grupo 1: " + salarioGrupo1);
        System.out.println("Salario Grupo 2: " + salarioGrupo2);
    }
    
}
abstract class CalculadoraSalario {

    protected double valorHora;// valor da hora

    public CalculadoraSalario(double valorHora) {
        this.valorHora = valorHora;
    }

    public abstract double calcSalario(int expediente);
}

class Grupo_1 extends CalculadoraSalario {

    public Grupo_1() {
        super(200.00);
    }

    @Override
    public double calcSalario(int expediente) {
        double SalarioBase = valorHora * expediente;
        double bonus = 0.3 * SalarioBase;
        double SalarioTotal = SalarioBase + bonus;
        return SalarioTotal;

    }
}

class Grupo_2 extends CalculadoraSalario {

    public Grupo_2() {
        super(250.00);

    }

    @Override
    public double calcSalario(int expediente) {
    
        return valorHora * expediente; 
    }
    
}