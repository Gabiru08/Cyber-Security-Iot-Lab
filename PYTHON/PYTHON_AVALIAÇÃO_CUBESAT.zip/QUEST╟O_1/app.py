def soma (x,y):
    resultado= x+y
    print(f"Valor 1: {x}")
    print(f"Valor 2: {y}")
    print(f"soma: {resultado}")

valor2=float(input("Digite o segundo valor:"))
soma(10,valor2)
