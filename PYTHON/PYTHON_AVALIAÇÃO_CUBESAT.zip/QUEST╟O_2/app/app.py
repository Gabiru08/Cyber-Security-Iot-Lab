def soma():
    valores=[]
   
    while True: 
        try:
           valor = float(input("Insira os valores ou 0 para encerrar:  "))
           if valor == 0 :
               break
           valores.append(valor)
        except ValueError:
            print("Valor inválido. Tente novamente.")
       
    resultado=sum(valores)
    return resultado

resultado = soma()
print(f"O valor da soma é {resultado}")

